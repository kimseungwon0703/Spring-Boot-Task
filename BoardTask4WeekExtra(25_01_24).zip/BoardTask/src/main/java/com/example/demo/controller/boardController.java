package com.example.demo.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.AnswerblockEntity;
import com.example.demo.entity.BoardEntity;
import com.example.demo.repository.AnswerblockRepository;
import com.example.demo.repository.BoardRepository;
import com.example.demo.userdto.BoardDTO;
import com.example.demo.userdto.UserDTO;

import jakarta.servlet.http.HttpSession;

/*
   Board Controller クラスです。
   掲示板の情報関連処理を進めます。
*/
@Controller
public class boardController {
	
	//掲示板データ保存及び照会
	@Autowired
    private BoardRepository boardRepo;
	
	@Autowired
    private AnswerblockRepository answerblockRepo;
    // 掲示板ページの表示
	// デフォルトでは、ページ番号を 0 で使用します。
	// ページは現在要求されたページ番号を示します。
    @GetMapping("/board")
    public String boardPage(@RequestParam(defaultValue = "0") int page, Model model, HttpSession session) {
    	
    	UserDTO loggedInUser = (UserDTO) session.getAttribute("loginUser"); 
    	String userName = (String) session.getAttribute("userName");
    	//ログイン後にユーザー名が無効になった例外を防止するための構文
    	if(userName != null) {
    		model.addAttribute("userName", userName);
    	}else {
    		return "redirect:/login";
    	}
        List<BoardEntity> boardList = boardRepo.findAllByOrderByIdDesc(); // 全体文を降順に並べ替える

        int maxPost = 5; // ページの文の最大個数
        long boardCount = boardRepo.count(); // 文の数を数える
        
        // ページ数を計算するためにMath.ceil()を使用してアップ処理し、残りで計算された文の数を含めます。
        int totalPages = (int) Math.ceil((double) boardCount / maxPost); // 全ページ数の計算

        //文がない場合は、空白のページで表示します。
        if (boardCount == 0) {
            totalPages = 0;
            boardList = List.of(); // 空いているリストに設定
        }
        
        // 現在のページに該当する掲示文を取得する
        int startPoint = page * maxPost; // 掲示文の開始を計算、2番目のページは6番からスタート
        int endPoint = Math.min((page + 1) * maxPost, boardList.size());
        // 掲示文の最後を計算する掲示文が全部で10個ならendPointは10
        // 投稿が7つあるとき、最初のページは(0 + 1)* 5 = 5、boardList.size() = 7、 Math.min(5,7) 最小値は5で、endPointは7です。
        // 二番目のページは(1 + 1) * 5 = 10、boardList.size() = 7、 Math.min(10,7) 最小値は7で、endPointは7です。
        List<BoardEntity> paginatedList = boardList.subList(startPoint, endPoint); // ページング処理
        // boardListでstartPointとendPointの間の掲示文だけを切り、新しいリスト(paginatedList)を作成

        // モデルにデータを追加
        model.addAttribute("posts", paginatedList);      // 現在のページの掲示文
        model.addAttribute("currentPage", page);         // 現在のページ番号
        model.addAttribute("totalPages", totalPages);    // 全ページ数

        return "board"; // board.html 移動
    }
    
    //掲示板の詳細を見る
    //{id}は、URL パスから動的に値を取得するパス変数です。
    //@PathVariable Long idは、URLパスから受け取ったid値を、Long タイプ変数としてメソッドのパラメータ idに割り当てます。
    @GetMapping("/board/{id}")
    public String postDetail(@PathVariable Long id, Model model,HttpSession session) {
    	//掲示文の有無を確認
        BoardEntity boardEntity = boardRepo.findById(id) // id値で情報を照会します。
            .orElseThrow(() -> new IllegalArgumentException("Invalid post ID: " + id));
        //再生回数増加処理
        boardEntity.setSeeCount(boardEntity.getSeeCount() + 1);
        boardRepo.save(boardEntity);
        
        BoardDTO boardDTO = BoardDTO.toBoardDTO(boardEntity); //DTO(Data Transfer Object)
        //必要な情報をEntityから受け取り、DTOオブジェクトに変換します。
        model.addAttribute("post", boardDTO); // 詳細掲示文データ伝達
        //ユーザーの名前を取得するための
        String loggedInUser = (String) session.getAttribute("userName");
        model.addAttribute("loggedInUser", loggedInUser);
        
        Iterable<AnswerblockEntity> answers = answerblockRepo.findByBoard(boardEntity); // 投稿に該当する返信のみ照会
        model.addAttribute("answers", answers);
        return "postDetail"; // 詳細ページへ移動
    }
    
    // 返信作成処理
    @PostMapping("/board/{id}/answers")
    public String addAnswer(@PathVariable Long id, @RequestParam String ansContent,HttpSession session) {
        // 掲示文情報を照会していない場合は例外発生
        BoardEntity boardEntity = boardRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid post ID: " + id));
        // 新しい返信作成
        AnswerblockEntity answerblock = new AnswerblockEntity();
        answerblock.setAnsContent(ansContent);
        answerblock.setBoard(boardEntity);  // 返信がその投稿に属するように設定
        //ログインしたユーザーの名前を取得するための(HTMLでアクセス権限を設定)
        String loggedInUser = (String) session.getAttribute("userName");
        answerblock.setWriter(loggedInUser);
        
        // 返信保存
        answerblockRepo.save(answerblock);
        return "redirect:/board/" + id;  // 当該投稿の詳細ページへのリダイレクト
    }
    
    // 掲示板削除
    @PostMapping("/board/{id}/delete")
    @Transactional
    public String deletePost(@PathVariable Long id) {
        //掲示文の有無を確認
        BoardEntity boardEntity = boardRepo.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Invalid post ID: " + id));
        //返信削除構文（返信が存在するときの削除機能のエラー解決構文）
        answerblockRepo.deleteByBoard(boardEntity);
        // 投稿の削除
        boardRepo.delete(boardEntity);
        System.out.println("Delete Successfuly operated"); // 定削的に削除されたか出力で確認
        return "redirect:/board"; // 掲示板一覧ページへのリダイレクト
    }
    
    // 返信削除
    @PostMapping("/board/{id}/answers/delete/{ansId}")
    public String deleteAnswer(@PathVariable Long id, @PathVariable Long ansId,HttpSession session,Model model) {
    	AnswerblockEntity answerblock = answerblockRepo.findById(ansId)
    	        .orElseThrow(() -> new IllegalArgumentException("Invalid answer ID: " + ansId));
    	//ログインしたユーザーの名前を取得するための(HTMLでアクセス権限を設定)
    	String loggedInUser = (String) session.getAttribute("userName");
        model.addAttribute("loggedInUser", loggedInUser);
        // 返信削除
        if (answerblock != null) {
            answerblockRepo.delete(answerblock);
        }
        return "redirect:/board/" + id;  // 当該投稿の詳細ページへのリダイレクト
    }
    
    // 返信修整
    @PostMapping("/board/{id}/answers/edit/{ansId}")
    public String editAnswer(@PathVariable Long id, @PathVariable Long ansId, @RequestParam String newContent,HttpSession session, Model model) {
    	//返信の番号を取得する。(ansId)
        AnswerblockEntity answerblock = answerblockRepo.findById(ansId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid answer ID: " + ansId));
        //ログインしたユーザーの名前を取得するための(HTMLでアクセス権限を設定)
        String loggedInUser = (String) session.getAttribute("userName");
        model.addAttribute("loggedInUser", loggedInUser);

        answerblock.setAnsContent(newContent); // 返事の番号をもらってきて(ansId)内容を修正
        answerblockRepo.save(answerblock); // 修正された内容を保存
        return "redirect:/board/" + id; // 当該投稿へのリダイレクト
    }
    
    // 文作成ページへ移動
    @GetMapping("/writepage")
    public String writePage() {
        return "writepage"; 
    }

    // 作成された文の保存
    @PostMapping("/writepage")
    public String SavePost(@ModelAttribute BoardEntity boardContent, HttpSession session,Model model) {  
        String writer = (String) session.getAttribute("userName");
    	
        if (writer != null) {
            boardContent.setWriter(writer);  // 作成者の名前を受け取るための
        } else {
        	model.addAttribute("message", "ログインが必要なサービスです。");
        	model.addAttribute("loginError", "/login");
            return "message";  // 情報がなければログインするように伝える
        }
    	
    	boardContent.setSeeCount(0L);  // 再生回数の初期値設定
        boardContent.setCreateDate(LocalDateTime.now());  // 現在の日付設定
    	boardRepo.save(boardContent); // 掲示文保存
        System.out.println(boardContent.toString()); // 正常に保存されているか出力文で確認
        return "redirect:/board"; // 掲示板ページへのリダイレクト
    }
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:login";
	}
	
	@GetMapping("/editContent/{id}")
	public String editPost(@PathVariable Long id, Model model) {
	    BoardEntity boardEntity = boardRepo.findById(id)
	        .orElseThrow(() -> new IllegalArgumentException("Invalid post ID: " + id));

	    model.addAttribute("post", boardEntity); // 現在の投稿情報をモデルに追加
	    return "editContent"; // editContent.htmlに移動
	}

	@PostMapping("/board/{id}/update")
	public String updatePost(@PathVariable Long id, @RequestParam String title, @RequestParam String content) {
	    BoardEntity boardEntity = boardRepo.findById(id)
	        .orElseThrow(() -> new IllegalArgumentException("Invalid post ID: " + id));

	    //タイトルと内容が修正されたものに設定後、データベースに保存
	    boardEntity.setTitle(title);
	    boardEntity.setContent(content); 
	    boardRepo.save(boardEntity);

	    return "redirect:/board/" + id; // 修正した掲示物に移動
	}

	@GetMapping("/board/findScript")
	public String findPost(@RequestParam String query, Model model,HttpSession session) {
		List<BoardEntity> searchResults = boardRepo.findByTitleContainingIgnoreCaseOrContentContainingIgnoreCase(query, query);
		
		//検索してもユーザーの名前とログアウトを行えるように変更
		String userName = (String) session.getAttribute("userName");
    	if(userName != null) {
    		model.addAttribute("userName", userName);
    	}else {
    		return "redirect:/login";
    	}
	    
	    // 作成された文章を読み込んで、該当部分だけ修正できるように変更
		model.addAttribute("posts", searchResults);
	    //掲示物は最初のページに設定、検索結果は1ページに設定
	    model.addAttribute("currentPage", 0);
	    model.addAttribute("totalPages", 1);
	    return "board"; // 検索結果を表示する掲示板ページに移動
	}
}
