package com.example.demo.interceptor;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Component
public class LoginInterceptor implements HandlerInterceptor {
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		String requestURI = request.getRequestURI();
		System.out.println("[interceptor] requestURI : " + requestURI);
		
		HttpSession session = request.getSession(false); //セッションがなければnull
		if(session == null || session.getAttribute("loginUser") == null) {
			//getAttributeはセッションに保存されたloginUserオブジェクトを読み込む値がnullであればログインしない状態とみなす。
			System.out.println("no point arrived"); //確認出力文
			response.sendRedirect("login"); //ログインできない場合はログインページに移動
			return false; //処理中断
		}
		return true;  // false->以降は進行しない。
	}
}
