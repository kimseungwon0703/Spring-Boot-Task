package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.UserEntity;
import com.example.demo.repository.UserRepository;
import com.example.demo.userdto.UserDTO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;


/*
   メインコントローラのクラスです。
   ユーザーの情報を入力して検証します。
*/
@Controller
public class mainController {

	
	//UserRepository Autowired ユーザーデータの保存と照会
	@Autowired
	private UserRepository userRepo;
	
	/*
	 * ログインと会員登録を選択するためのメインページです。 
	 * mainpage.htmlの選択により、ログインと会員登録の相互移動が可能です。
	 */
	@GetMapping("/mainpage")
	public String mainpage() {
		return "mainpage";
	}
	
    // 会員登録ページの表示
    @GetMapping("/register")
    public String register() {
        return "register"; // register.html 表示
    }

	/*
	 * 会員登録後、ログインページに移動 input Password : ページの入力されたパスワード文字列を取得します
	 * confirmPassword:ページの入力されたパスワード確認文字列を取得します.
	 */
    @PostMapping("/register")
    public String registerToLogin(@ModelAttribute UserEntity user) {
        String inputPassword = user.getPassword();
        String confirmPassword = user.getConfirmPassword();

		/*
		 * 入力されたパスワードとパスワード確認文字列をequals()を通じて比較し、真の場合はUserRepositoryに情報を保存し
		 * ログインページに移動します。 嘘であれば保存せずに登録ページを維持します。
		 */
        if (inputPassword != null && inputPassword.equals(confirmPassword)) {
            userRepo.save(user);
            System.out.println(user.toString());
            return "login";
        } else {
            return "register";
        }
    }
    
    // ログインページ表示
    @GetMapping("/login")
    public String ShowLoginPage() {
        return "login"; // login.html 表示
    }

	/*
	 * ログイン リクエストを処理し、掲示板のページに移動します。
	 * username : ユーザーが入力したユーザー名
	 * password : ユーザーが入力したパスワード
	 * return : ログインに成功するとboard.html、失敗するとlogin.htmlに移動します。
	 */
    @PostMapping("/login")
    public String LoginPageToBoardPage(@RequestParam String username,
    								   @RequestParam String password,
    								   HttpServletRequest request) {
    	UserEntity userEntity = userRepo.findByUsername(username);

        // ユーザー情報の存在有無とパスワードの一致確認
        if (userEntity != null) {
            UserDTO userDTO = UserDTO.toMemberDTO(userEntity);  // UserEntityをUserDTOに変換
            if (userDTO.getPassword().equals(password)) {
            	HttpSession session = request.getSession();
            	session.setAttribute("loginUser", userDTO); //セッションにuserDTOを保存
                return "redirect:/board"; // パスワードが一致すると掲示板ページに移動
            } else {
                return "login"; // パスワードが一致しない場合は、再度ログインページに移動します
            }
        } 
        return "register"; // IDが存在しない場合は会員登録ページへ移動
    }

}
