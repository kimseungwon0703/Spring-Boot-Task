package com.example.demo.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

import com.example.demo.entity.BoardEntity;

/*titleとcontent値を基準にデータベースからBoard Entityを検索します。*/
public interface BoardRepository extends CrudRepository<BoardEntity, Long>{
	BoardEntity findByTitle(String title); // タイトル
	BoardEntity findByContent(String content); // 内容.
	
	List<BoardEntity> findAllByOrderByIdDesc(); // 降順に整列
}
