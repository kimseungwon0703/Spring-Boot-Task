package com.example.demo.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

import com.example.demo.entity.BoardEntity;

/*titleとcontent値を基準にデータベースからBoard Entityを検索します。*/
public interface BoardRepository extends CrudRepository<BoardEntity, Long>{
	BoardEntity findByTitle(String title); // タイトル
	BoardEntity findByContent(String content); // 内容.
	//titleフィールドに与えられた文字列が含まれているか、content フィールドに与えられた文字列が含まれているすべてのエンティティを大文字と小文字の区別なく検索します。
	List<BoardEntity> findByTitleContainingIgnoreCaseOrContentContainingIgnoreCase(String title, String content);
	
	List<BoardEntity> findAllByOrderByIdDesc(); // 降順に整列
}
