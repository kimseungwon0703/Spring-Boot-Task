package com.example.demo.userdto;

import com.example.demo.entity.BoardEntity;
// Board Repositoryに保存されたログインに必要な情報であるidとtitleとcontentをDTOを通じてコントローラーに転送します。
public class BoardDTO {
	private Long id;
	private String title;
	private String content;
	
	//Entityの必要な情報を使用するためのDTO作成
	public static BoardDTO toBoardDTO(BoardEntity boardentity) {
		BoardDTO boardDTO = new BoardDTO();
		boardDTO.setId(boardentity.getId());
		boardDTO.setTitle(boardentity.getTitle());
		boardDTO.setContent(boardentity.getContent());
		return boardDTO;
	}
	
	/* Getter & Setter 設定. */
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	
}
