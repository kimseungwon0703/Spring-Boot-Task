package com.example.demo.userdto;

import java.time.LocalDateTime;

import com.example.demo.entity.BoardEntity;
// Board Repositoryに保存されたログインに必要な情報であるidとtitleとcontentをDTOを通じてコントローラーに転送します。
public class BoardDTO {
	private Long id;
	private Long seeCount;
	private String title; 
	private String content; 
	private String writer;
	private LocalDateTime createDate;
	
	//Entityの必要な情報を使用するためのDTO作成
	public static BoardDTO toBoardDTO(BoardEntity boardentity) {
		BoardDTO boardDTO = new BoardDTO();
		boardDTO.setId(boardentity.getId());
		boardDTO.setTitle(boardentity.getTitle());
		boardDTO.setContent(boardentity.getContent());
		boardDTO.setSeeCount(boardentity.getSeeCount());
		boardDTO.setWriter(boardentity.getWriter());
		boardDTO.setCreateDate(boardentity.getCreateDate());
		return boardDTO;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getSeeCount() {
		return seeCount;
	}

	public void setSeeCount(Long seeCount) {
		this.seeCount = seeCount;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public LocalDateTime getCreateDate() {
		return createDate;
	}

	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}
	
	/* Getter & Setter 設定. */
	
	
	
}
