package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.BoardEntity;
import com.example.demo.repository.BoardRepository;
import com.example.demo.userdto.BoardDTO;

/*
   Board Controller クラスです。
   掲示板の情報関連処理を進めます。
*/
@Controller
public class boardController {
	
	//掲示板データ保存及び照会
	@Autowired
    private BoardRepository boardRepo;

    // 掲示板ページの表示
	// デフォルトでは、ページ番号を 0 で使用します。
	// ページは現在要求されたページ番号を示します。
    @GetMapping("/board")
    public String boardPage(@RequestParam(defaultValue = "0") int page, Model model) {
        List<BoardEntity> boardList = boardRepo.findAllByOrderByIdDesc(); // 全体文を降順に並べ替える

        int maxPost = 5; // ページの文の最大個数
        long boardCount = boardRepo.count(); // 文の数を数える
        
        // ページ数を計算するためにMath.ceil()を使用してアップ処理し、残りで計算された文の数を含めます。
        int totalPages = (int) Math.ceil((double) boardCount / maxPost); // 全ページ数の計算

        //文がない場合は、空白のページで表示します。
        if (boardCount == 0) {
            totalPages = 0;
            boardList = List.of(); // 空いているリストに設定
        }
        
        // 現在のページに該当する掲示文を取得する
        int startPoint = page * maxPost; // 掲示文の開始を計算、2番目のページは6番からスタート
        int endPoint = Math.min((page + 1) * maxPost, boardList.size());
        // 掲示文の最後を計算する掲示文が全部で10個ならendPointは10
        // 投稿が7つあるとき、最初のページは(0 + 1)* 5 = 5、boardList.size() = 7、 Math.min(5,7) 最小値は5で、endPointは7です。
        // 二番目のページは(1 + 1) * 5 = 10、boardList.size() = 7、 Math.min(10,7) 最小値は7で、endPointは7です。
        List<BoardEntity> paginatedList = boardList.subList(startPoint, endPoint); // ページング処理
        // boardListでstartPointとendPointの間の掲示文だけを切り、新しいリスト(paginatedList)を作成

        // モデルにデータを追加
        model.addAttribute("posts", paginatedList);      // 現在のページの掲示文
        model.addAttribute("currentPage", page);         // 現在のページ番号
        model.addAttribute("totalPages", totalPages);    // 全ページ数

        return "board"; // board.html 이동
    }
    
    //掲示板の詳細を見る
    //{id}は、URL パスから動的に値を取得するパス変数です。
    //@PathVariable Long idは、URLパスから受け取ったid値を、Long タイプ変数としてメソッドのパラメータ idに割り当てます。
    @GetMapping("/board/{id}")
    public String postDetail(@PathVariable Long id, Model model) {
    	//掲示文の有無を確認
        BoardEntity boardEntity = boardRepo.findById(id) // id値で情報を照会します。
            .orElseThrow(() -> new IllegalArgumentException("Invalid post ID: " + id));
        BoardDTO boardDTO = BoardDTO.toBoardDTO(boardEntity); //DTO(Data Transfer Object)
        //必要な情報をEntityから受け取り、DTOオブジェクトに変換します。
        model.addAttribute("post", boardDTO); // 詳細掲示文データ伝達
        return "postDetail"; // 詳細ページへ移動
    }
    
    // 掲示板削除処理
    @PostMapping("/board/{id}/delete")
    public String deletePost(@PathVariable Long id) {
        //掲示文の有無を確認
        BoardEntity boardEntity = boardRepo.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Invalid post ID: " + id));
        // 게시글 삭제
        boardRepo.delete(boardEntity);
        System.out.println("Delete Successfuly operated"); // 定削的に削除されたか出力で確認
        return "redirect:/board"; // 掲示板一覧ページへのリダイレクト
    }
    
    // 文作成ページへ移動
    @GetMapping("/writepage")
    public String writePage() {
        return "writepage"; 
    }

    // 作成された文の保存
    @PostMapping("/writepage")
    public String SavePost(@ModelAttribute BoardEntity boardContent) {
        boardRepo.save(boardContent); // 掲示文保存
        System.out.println(boardContent.toString()); // 正常に保存されているか出力文で確認
        return "redirect:/board"; // 掲示板ページへのリダイレクト
    }
}
