package com.example.demo.userdto;

//投稿の返信を管理するためのDTO
public class AnswerblockDTO {

    private String ansContent;
    
    //Getter & Setter 設定.
    public String getAnsContent() {
        return ansContent;
    }

    public void setAnsContent(String ansContent) {
        this.ansContent = ansContent;
    }
}