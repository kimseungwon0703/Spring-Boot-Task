package com.example.demo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.example.demo.interceptor.LoginInterceptor;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Autowired
    private LoginInterceptor logInter; //自動的にBeanに注入

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(logInter) // 自動注入されたLoginInterceptorを使用
        		.addPathPatterns("/board", "/writepage", "/postDetail") // ログイン状態が必要なページにのみインターセプターを適用
                .excludePathPatterns("/login", "/register", "/mainpage"); // ログイン、メインページ、会員登録ページは除く
    }
}