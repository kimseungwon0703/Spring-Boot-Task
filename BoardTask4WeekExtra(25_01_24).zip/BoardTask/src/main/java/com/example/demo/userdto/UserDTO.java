package com.example.demo.userdto;

import com.example.demo.entity.UserEntity;

/*User Repositoryに保存されたログインに必要な情報であるusernameとpasswordをDTOを通じてコントローラーに転送します。*/
public class UserDTO {
	
	private String username;
	private String password;
	private String confirmpassword;
	private String name;
	private String email;
	private String phone;
	
	/* UserEntityオブジェクトをUserDTOオブジェクトに変換 */
	public static UserDTO toMemberDTO(UserEntity userentity) {
		UserDTO userDTO = new UserDTO();
		userDTO.setUsername(userentity.getUsername());
		userDTO.setPassword(userentity.getPassword());
		userDTO.setConfirmpassword(userentity.getConfirmPassword());
		userDTO.setName(userentity.getName());
		userDTO.setEmail(userentity.getEmail());
		userDTO.setPhone(userentity.getPhone());
		return userDTO;
	}
	
	/* Getter & Setter 設定. */
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	

}
