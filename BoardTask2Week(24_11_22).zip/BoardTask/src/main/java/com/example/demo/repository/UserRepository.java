package com.example.demo.repository;

import com.example.demo.entity.UserEntity;
import org.springframework.data.repository.CrudRepository;

/*usernameとpassword値に基づいてデータベースからUserEntityを検索します。*/
public interface UserRepository extends CrudRepository<UserEntity, Long> {
	UserEntity findByUsername(String username); // ユーザー名
	UserEntity findByPassword(String password); // ユーザーパスワード
}
