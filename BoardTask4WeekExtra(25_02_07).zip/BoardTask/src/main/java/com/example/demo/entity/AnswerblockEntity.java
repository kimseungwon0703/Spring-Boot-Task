package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class AnswerblockEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ansId;
    private String ansContent;
    private String writer;
	
	// @ManyTOOne:このアノテーションは現在、エンティティ(AnswerblockEntity)が 
	// 他のエンティティ(Board Entity)と多対一(Many-to-One)関係を結んでいることを示します。
	// つまり、複数の返信(Answerblock Entity)が一つの投稿(Board Entity)に属することになります。
	// [board] フィールドは、返信が属する投稿と接続され、その投稿を参照します。
    @ManyToOne
    private BoardEntity board;

    // Getters & Setters 設定
    public Long getAnsId() {
        return ansId;
    }

    public void setAnsId(Long ansId) {
        this.ansId = ansId;
    }

    public String getAnsContent() {
        return ansContent;
    }

    public void setAnsContent(String ansContent) {
        this.ansContent = ansContent;
    }

    public BoardEntity getBoard() {
        return board;
    }

    public void setBoard(BoardEntity board) {
        this.board = board;
    }

    public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	//出力のためのtoString()
	@Override
	public String toString() {
		return "AnswerblockEntity [ansId=" + ansId + ", ansContent=" + ansContent + ", writer=" + writer + ", board="
				+ board + "]";
	}

    
}