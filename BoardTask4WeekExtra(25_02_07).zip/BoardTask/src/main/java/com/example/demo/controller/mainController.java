package com.example.demo.controller;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.UserEntity;
import com.example.demo.repository.UserRepository;
import com.example.demo.userdto.UserDTO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;


/*
   メインコントローラのクラスです。
   ユーザーの情報を入力して検証します。
*/
@Controller
public class mainController {

	//UserRepository Autowired ユーザーデータの保存と照会
	@Autowired
	private UserRepository userRepo;
	
	/*
	 * ログインと会員登録を選択するためのメインページです。 
	 * mainpage.htmlの選択により、ログインと会員登録の相互移動が可能です。
	 */
	@GetMapping("/mainpage")
	public String mainpage() {
		return "mainpage";
	}
	
    // 会員登録ページの表示
    @GetMapping("/register")
    public String register(Model model) {
    	model.addAttribute("user", new UserEntity()); // 会員登録で例外が発生した場合、ユーザーが入力した情報を維持するためのコード
        return "register"; // register.html 表示
    }

	/*
	 * 会員登録後、ログインページに移動 input Password : ページの入力されたパスワード文字列を取得します
	 * confirmPassword:ページの入力されたパスワード確認文字列を取得します.
	 */
    @PostMapping("/register")
    public String registerToLogin(@RequestParam String action, @ModelAttribute UserEntity user, Model model,HttpSession session) {
        String inputPassword = user.getPassword();
        String confirmPassword = user.getConfirmPassword();
        
        if("confirmPassword".equals(action)) {
        	if (inputPassword != null && inputPassword.equals(confirmPassword)) {
        		model.addAttribute("confirm","パスワードが一致します。");
        		session.setAttribute("step","userInfoInput");
        		session.setAttribute("passwordChecked", true);
        	}else {
        		model.addAttribute("confirm","パスワードが一致しません。");
        		user.setPassword("");  // パスワード確認後、失敗時に入力したパスワード化パスワード確認のみ削除
                user.setConfirmPassword("");
                session.removeAttribute("passwordChecked");
        	}
        }

        //入力したパスワードを"confirm Password".equals(action)を通じて確認し、一致すればセッションに保存されたデータを通じて会員登録を進めます。
        if ("registerCheck".equals(action)) {
        	Boolean passwordChecked = (Boolean) session.getAttribute("passwordChecked"); 
            if (Boolean.TRUE.equals(passwordChecked) && "userInfoInput".equals(session.getAttribute("step"))) {
            	if (user.getName() == null || user.getName().isEmpty() || 
                        user.getEmail() == null || user.getEmail().isEmpty() || 
                        user.getPhone() == null || user.getPhone().isEmpty()) {
            		//入力した情報がすべて満たされていることを確認
                        model.addAttribute("message", "会員登録失敗: すべての情報を入力する必要があります。");
                        model.addAttribute("registerFail", "/register");
                        return "message"; // 
                    }
                // パスワード暗号化
                BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
                String hashedPassword = passwordEncoder.encode(inputPassword);
                user.setPassword(hashedPassword); // 暗号化されたパスワードに設定
                
                // ユーザー情報保存
                userRepo.save(user); 
                
                session.removeAttribute("passwordChecked");
                session.removeAttribute("step");
                
                model.addAttribute("message", "会員登録成功");
                model.addAttribute("registerSuccess", "/login");
                return "message";
            } else {
                model.addAttribute("message", "会員登録失敗:パスワードの確認を先に行ってください。");
                model.addAttribute("registerFail", "/register");
                return "message";
            }
        }
        // 例外処理が発生した場合、ユーザー情報を再びモデルに追加して、エラーが発生してもユーザーが入力した情報が維持されるようにします。
        model.addAttribute("user", user);
        return "register";
    }
    
    // ログインページ表示
    @GetMapping("/login")
    public String ShowLoginPage() {
        return "login"; // login.html 表示
    }
	/*
	 * ログイン リクエストを処理し、掲示板のページに移動します。
	 * username : ユーザーが入力したユーザー名
	 * password : ユーザーが入力したパスワード
	 * return : ログインに成功するとboard.html、失敗するとlogin.htmlに移動します。
	 */
    @PostMapping("/login")
    public String LoginPageToBoardPage(@RequestParam String username,
    								   @RequestParam String password,
    								   HttpServletRequest request, Model model) {
    	UserEntity userEntity = userRepo.findByUsername(username);
        // ユーザー情報の存在有無とパスワードの一致確認
        if (userEntity != null) {
        	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
            UserDTO userDTO = UserDTO.toMemberDTO(userEntity);  // UserEntityをUserDTOに変換
            
            if (passwordEncoder.matches(password, userEntity.getPassword())) {
            	HttpSession session = request.getSession();
            	session.setAttribute("loginUser", userDTO); //セッションにuserDTOを保存, 掲示板ページにユーザー名を表示するための
            	session.setAttribute("userName", userDTO.getUsername());
            	
            	model.addAttribute("message", "ログイン成功しました。");
                model.addAttribute("loginSuccess", "/board");
                return "message"; // パスワードが一致すると掲示板ページに移動
            } else {
            	model.addAttribute("message", "IDまたはパスワードが間違っています。");
                model.addAttribute("loginFail", "/login"); 
                return "message"; // パスワードが一致しない場合は、再度ログインページに移動します
            }
        } 
        model.addAttribute("message", "IDまたはパスワードが間違っています。");
        model.addAttribute("loginFail", "/login");
        return "message"; // IDが存在しない場合は会員登録ページへ移動
    }
}
