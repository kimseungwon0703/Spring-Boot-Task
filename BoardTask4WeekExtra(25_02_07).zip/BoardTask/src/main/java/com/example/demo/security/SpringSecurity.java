package com.example.demo.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.header.writers.frameoptions.XFrameOptionsHeaderWriter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration // 이 클래스가 Spring의 설정 클래스임을 나타냅니다.
@EnableWebSecurity // Spring Security機能を有効にします。
public class SpringSecurity {

    @Bean // このメソッドがSpringのBeanとして登録します。
    SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // リクエストに対する権限付与の設定、すべての権限を許可します。
            .authorizeHttpRequests((authorizeHttpRequests) -> authorizeHttpRequests
                .requestMatchers(new AntPathRequestMatcher("/**")).permitAll())
            // CSRF(Cross-Site Request Forgery) 保護設定
            .csrf((csrf) -> csrf
                // H2 コンソールに対するCSRF保護を無効にします。
                .ignoringRequestMatchers(new AntPathRequestMatcher("/h2-console/**")))
            // HTTP応答ヘッダー設定
            .headers((headers) -> headers
                // X-Frame-Optionsヘッダーを設定して、クリックジャッキング攻撃を防止します。
                .addHeaderWriter(new XFrameOptionsHeaderWriter(
                    XFrameOptionsHeaderWriter.XFrameOptionsMode.SAMEORIGIN)))
        ;
        // 設定されたHttp Securityオブジェクトに基づいてSecurity Filter Chainをビルドして返します。
        return http.build();
    }
}