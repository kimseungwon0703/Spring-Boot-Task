package com.example.demo.repository;

import org.springframework.data.repository.CrudRepository;
import com.example.demo.entity.AnswerblockEntity;
import com.example.demo.entity.BoardEntity;

public interface AnswerblockRepository extends CrudRepository<AnswerblockEntity, Long> {
	// findByBoardメソッドは、特定の投稿に属するすべての返信を照会します。
	// Iterable<Answerblock Entity>:このメソッドは、Answerblock EntityオブジェクトのIterableコレクションを返します。
	// Iterableは最上位インターフェースで、リスト(List)、セット(Set)など反復可能なコレクションを処理することができます。
	// このメソッドは、与えられたBoard Entityに接続されたすべての返信を含むコレクションを返します。
	Iterable<AnswerblockEntity> findByBoard(BoardEntity board);
	
	//掲示文とその文(board)の解答(ans Content)を探すためのメソッドです。
	 AnswerblockEntity findByBoardAndAnsContent(BoardEntity board, String ansContent);
	 void deleteByBoard(BoardEntity board);
}
