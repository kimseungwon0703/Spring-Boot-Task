package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class BoardEntity {
	
	/*
	  投稿番号、タイトル、内容を保存するフィールドです。
	  登録が追加されると、自動的に固有のID値を増加させます。
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; // 投稿番号
	private String title; // タイトル
	private String content; // 内容
	
	//出力のためのtoString()
	@Override
	public String toString() {
		return "BoardEntity [Id=" + id + ", title=" + title + ", content=" + content + "]";
	}

	// Getters & Setters 設定
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	

}
