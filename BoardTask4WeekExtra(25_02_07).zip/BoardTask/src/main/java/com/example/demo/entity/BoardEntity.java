package com.example.demo.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class BoardEntity {
	
	/*
	  投稿番号、タイトル、内容を保存するフィールドです。
	  登録が追加されると、自動的に固有のID値を増加させます。
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; // 投稿番号
	private Long seeCount = 0L; //初期値設定
	private String title; // タイトル
	private String content; // 内容
	private String writer;
	private LocalDateTime createDate;
	
	//出力のためのtoString()
	@Override
    public String toString() {
        return "BoardEntity [Id=" + id + ", title=" + title + ", content=" + content + ", writer=" + writer +
                ", seeCount=" + seeCount + ", createDate=" + createDate + "]";
    }

	// Getters & Setters 設定
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Long getSeeCount() {
		return seeCount;
	}

	public void setSeeCount(Long seeCount) {
		this.seeCount = seeCount;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public LocalDateTime getCreateDate() {
		return createDate;
	}

	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}
	
	

}
